module.exports = {
  extends: ['stylelint-config-shopify/prettier'],
};
